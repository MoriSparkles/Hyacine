<?php

/** @var yii\web\View $this */
/** @var array $recentArranges */
/** @var array $currentArranges */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = '教室预约系统';
?>
<div class="site-index">
   

    <!-- 功能导航 -->
    <div class="row mb-4">
        <div class="col-md-12">
            <nav class="navbar navbar-expand-lg navbar-light bg-light rounded shadow-sm">
                <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/course/index']) ?>">
                                    <i class="fas fa-book"></i> 课程管理
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/course-cat/index']) ?>">
                                    <i class="fas fa-tags"></i> 课程分类
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/course-arrange/index']) ?>">
                                    <i class="fas fa-calendar-alt"></i> 课程安排
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/room/index']) ?>">
                                    <i class="fas fa-door-open"></i> 教室管理
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= Url::to(['/semester/index']) ?>">
                                    <i class="fas fa-clock"></i> 学期管理
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>

    <div class="body-content">
        <!-- 统计卡片 -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card text-white bg-primary">
                    <div class="card-body">
                        <h5 class="card-title">课程总数</h5>
                        <p class="card-text display-4"><?= $courseCount ?></p>
                        <a href="<?= Url::to(['/course/index']) ?>" class="btn btn-light">查看详情</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-success">
                    <div class="card-body">
                        <h5 class="card-title">教室总数</h5>
                        <p class="card-text display-4"><?= $roomCount ?></p>
                        <a href="<?= Url::to(['/room/index']) ?>" class="btn btn-light">查看详情</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-white bg-info">
                    <div class="card-body">
                        <h5 class="card-title">课程安排</h5>
                        <p class="card-text display-4"><?= $courseArrangeCount ?></p>
                        <a href="<?= Url::to(['/course-arrange/index']) ?>" class="btn btn-light">查看详情</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- 最近课程安排 -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">最近课程安排</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($recentArranges as $arrange): ?>
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?= Html::encode($arrange->course->course_name ?? '未知课程') ?></h6>
                                        <small>ID: <?= $arrange->id ?></small>
                                    </div>
                                    <p class="mb-1">
                                        教室：<?= Html::encode($arrange->room->room_name ?? '未知教室') ?><br>
                                        教师：<?= Html::encode($arrange->tutor_name) ?><br>
                                        时间：星期<?= ['一','二','三','四','五','六','日'][$arrange->c_day-1] ?> 第<?= $arrange->c_day_time ?>节
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">当前学期课程安排</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($currentArranges as $arrange): ?>
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?= Html::encode($arrange->course->course_name ?? '未知课程') ?></h6>
                                        <small>ID: <?= $arrange->id ?></small>
                                    </div>
                                    <p class="mb-1">
                                        教室：<?= Html::encode($arrange->room->room_name ?? '未知教室') ?><br>
                                        教师：<?= Html::encode($arrange->tutor_name) ?><br>
                                        时间：星期<?= ['一','二','三','四','五','六','日'][$arrange->c_day-1] ?> 第<?= $arrange->c_day_time ?>节
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 添加 Font Awesome 图标库 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
